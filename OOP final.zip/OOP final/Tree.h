#pragma once

#include "Obstacle.h"

class Tree: public Obstacle
{
public:
    Tree(LTexture* image, float x, float y, int type);
    Tree();
    virtual ~Tree();
    void Move();
    void Render(long int& frame, SDL_Renderer* gRenderer, bool debug);
    //bool loadMedia();
};

