#pragma once
#include <cmath>
#include <math.h>
#define PI 3.14159265
#include "GameObjects.h"

class Bullet: public GameObjects
{
public:
    Bullet(LTexture* image, float x, float y, int type);
    Bullet();
    float Bullet_Pigeon(float, float);
    virtual ~Bullet();
    virtual void Move();
    virtual void Render(long int& frame, SDL_Renderer* gRenderer, bool debug);

protected:
    double x_coordinate;
    double y_coordinate;
};

