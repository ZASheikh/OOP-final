#include "Timer.h"

Timer::Timer()
{
    //ctor
}

Timer::~Timer()
{
    //dtor
}
