#pragma once

#include "Bullet.h"

class Plane_Bullet: public Bullet
{
public:
    Plane_Bullet(LTexture* image, float x, float y, int type);
    Plane_Bullet();
    float Bullet_Pigeon(float, float);
    virtual ~Plane_Bullet();
    virtual void Move();
    virtual void Render(long int& frame, SDL_Renderer* gRenderer, bool debug);

protected:
    double x_coordinate;
    double y_coordinate;
    float angle;
    float gradient;
};

