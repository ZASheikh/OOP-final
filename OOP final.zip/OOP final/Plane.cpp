#include "Plane.h"

///Overloaded constructor
Plane::Plane(LTexture* image, float x, float y, int type):Enemy(image, x, y, type)
{
    spriteSheetTexture = image;


    //Frame 0
    spriteClips[ 0 ].x = 300;
    spriteClips[ 0 ].y = 10;
    spriteClips[ 0 ].w = 160;
    spriteClips[ 0 ].h = 90;

    this->width = spriteClips[ 0 ].w;
    this->height = spriteClips[ 0 ].h;
}

///Destructor
Plane::~Plane()
{
    cout<<"Plane Deallocated"<<endl;
}

///Move function for Plane
void Plane::Move()
{
    x = x - 4;
    if (x < -40)
    {
        SetAlive(false);
    }
}

///Render function for Plane
void Plane::Render(long int& frame, SDL_Renderer* gRenderer, bool debug)
{
    spriteSheetTexture->Render( x - width/2 , y - height/2, &spriteClips[ frame % 1 ], 0.0 , NULL, SDL_FLIP_NONE, gRenderer );
    if(debug == true)
    {
        SDL_Rect rect = { x - width/2, y - height/2, width, height };
        SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xFF );
        SDL_RenderDrawRect( gRenderer, &rect );
    }
}
