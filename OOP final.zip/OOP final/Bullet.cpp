#include"Bullet.h"

Bullet::Bullet()
{

}

Bullet::~Bullet()
{
    cout<<"Bullet Deallocated"<<endl;
}

Bullet::Bullet(LTexture* image, float x, float y, int type):GameObjects(image, x, y, type)
{

}

float Bullet::Bullet_Pigeon(float x, float y)
{

}

void Bullet::Move()
{

}

void Bullet::Render(long int& frame, SDL_Renderer* gRenderer, bool debug)
{

}
