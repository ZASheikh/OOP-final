#pragma once

#include "Bullet.h"

class Infantry_Bullet: public Bullet
{
public:
    Infantry_Bullet(LTexture* image, float x, float y, int type);
    Infantry_Bullet();
    float Bullet_Pigeon(float, float);
    virtual ~Infantry_Bullet();
    void Move();
    void Render(long int& frame, SDL_Renderer* gRenderer, bool debug);

protected:
    double x_coordinate;
    double y_coordinate;
    float angle;
    float gradient;
};


