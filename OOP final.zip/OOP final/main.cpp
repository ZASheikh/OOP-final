#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <cmath>
#include "LTexture.h"
#include "Queue.h"
#include "Unit.h"
#include "Enemy.h"
#include "Bullet.h"
#include "Plane.h"
#include "Tree.h"
#include "Eagle.h"
#include "GameObjects.h"
#include <cstdlib>
#include "Pigeon.h"
#include "Pigeon_bullet.h"
#include "Plane_Bullet.h"
#include "Parcel.h"
#include "Powerup.h"
#include "PowerupStealth.h"
#include "Infantry.h"
#include "Infantry_Bullet.h"
#include "Enemy_Bullet.h"
#include "Tank.h"
#include "Timer.h"
#include "BulletFactory.h"
#define PI 3.14159265

using namespace std;
//Pre defined screen width and height
const int SCREEN_WIDTH = 1350;
const int SCREEN_HEIGHT = 750;

bool init();

bool loadMedia();

void close();

void Line( const float, const float, const float, const float);//, const Color&);

SDL_Window* gWindow = NULL;

SDL_Renderer* gRenderer = NULL;

LTexture gSpriteSheetTexture;

LTexture gBackground;
LTexture healthTexture;
LTexture StealthTexture;
//The surface contained by the window
SDL_Surface* gScreenSurface = NULL;

Pigeon* Pigeon::instance = NULL;
Parcel* Parcel::instance = NULL;


int main( int argc, char* args[] )
{
    BulletFactory factory;
    Bullet* bullet;
    Timer timme;
	if( !init() )
	{
		printf( "Failed to initialize!\n" );
	}
	else
	{
		//Load media
		if( !loadMedia() )
		{
			printf( "Failed to load media!\n" );
		}
		else
		{

			bool quit = false;                      //Main loop flag

			SDL_Event e;                            //Event handler

			long int frame = 0;                     //Current animation frame
			int bulletDelay = 0;
			//background scrolling offset
			int scrolling = 0;
			/* initialize random seed: */
            srand (time(NULL));

            /* generate secret number between 1 and 10: */
            //int random_1 = 0;

			Queue objectList;

            bool keypress = false;

			GameObjects* pigeon = Pigeon::GetInstance(&gSpriteSheetTexture, (float)SCREEN_WIDTH/8, (float)SCREEN_HEIGHT/8, 0);  // Singleton design method used;
			Enemy* tank = NULL;
            Bullet* enemy_bullet = NULL;
            Enemy* plane_new = NULL;
            Obstacle* tree_new = NULL;
            Obstacle* eagle = NULL;
            Bullet* p_bullet = NULL;
            Bullet* jet_bullet = NULL;
            Bullet* inf_bullet = NULL;
            GameObjects* parcel = Parcel::GetInstance(&gSpriteSheetTexture, SCREEN_WIDTH, 250, 9);
            Enemy* infantry = NULL;
            GameObjects* health = NULL;
            GameObjects* stealth = NULL;


			while( !quit )                          //While application is running
			{
			    timme.start();
			    if((timme.startTicks-timme.get_ticks())/1000==10)
                {
                   // break;
                }
			    cout<<(timme.startTicks-timme.get_ticks())/1000<<endl;
			    int ran = (rand() % 30)+50; /*Generates random number*/
			    int ran1 = (rand() % 400) + 200; /*Generates random number*/
			    int random = (rand() % 10) + 30; /*Generates random number*/
			    if(frame%800 == 0)
                {
                    //Creates a plane object
                    plane_new = new Plane(&gSpriteSheetTexture, SCREEN_WIDTH, 75,1);
                    objectList.Enqueue(plane_new);

                    //Creates an eagle object
                    eagle = new Eagle(&gSpriteSheetTexture, SCREEN_WIDTH, 200,2);
                    objectList.Enqueue(eagle);
                }
                if (frame%ran == 0)
                {
                    int ran2 = (rand() % 10)+620; /*Generates random number*/
                    //Creates tree object
                    tree_new = new Tree(&gSpriteSheetTexture, SCREEN_WIDTH, ran2,5);
                    objectList.Enqueue(tree_new);
                }

                if (frame%ran1 == 0)
                {
                    //Creates tank object
                    tank = new Tank(&gSpriteSheetTexture, SCREEN_WIDTH+20, 650, 3);
                    objectList.Enqueue(tank);
                }

                if (frame%300 == 0)
                {
                    //Creates infantry object
                    infantry = new Infantry(&gSpriteSheetTexture, SCREEN_WIDTH+40, 650,6);
                    objectList.Enqueue(infantry);
                }

                if (frame%75 == 0)
                {
                    //Creates infantry bullet
                    bullet = factory.GetBullet(&gSpriteSheetTexture, infantry->GetX(), infantry->GetY(),7);
                    objectList.Enqueue(bullet);
                    inf_bullet->Bullet_Pigeon(infantry->GetX(), infantry->GetY());
                }

                if (frame%150 == 0)
                {
                    //Creates tank bullet
                    bullet = factory.GetBullet(&gSpriteSheetTexture, tank->GetX(), tank->GetY(),4);
                    objectList.Enqueue(bullet);
                    enemy_bullet->Bullet_Pigeon(tank->GetX(), pigeon->GetY());
                }



                if ((frame % 75 == 0) & (pigeon->GetStealth() == 3))
                {
                    //Creates plane bullet
                    bullet = factory.GetBullet(&gSpriteSheetTexture, plane_new->GetX(), plane_new->GetY(), 8);
                    jet_bullet->Bullet_Pigeon(168.75, pigeon->GetY());
                    objectList.Enqueue(bullet);
                    bullet->Move();
                }

                if ((parcel->GetAnimate() == true) & (((timme.startTicks-timme.get_ticks())/1000) == random))
                {
                   //Checks if the parcel has been collected or not
                    objectList.Enqueue(parcel);
                    parcel->SetAnimate(false);
                }

                if (frame % 2000 == 0)
                {
                    health = new PowerUp(&gSpriteSheetTexture, 2*SCREEN_WIDTH, 150, 0);
                    objectList.Enqueue(health);

                    stealth = new PowerupStealth(&gSpriteSheetTexture, 2*SCREEN_WIDTH, 300, 0);
                    objectList.Enqueue(stealth);
                }

                objectList.Clean(); //Deletes the queue

                while( SDL_PollEvent( &e ) != 0 )   //Handle events on queue
                {
                    //User requests quit
                    if( e.type == SDL_QUIT )
                    {
                        quit = true;
                    }
                    if(e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_SPACE)
                    {
                        keypress = !(keypress);//true;
                    }
                }

                const Uint8* currentKeyStates = SDL_GetKeyboardState( NULL );

                if(currentKeyStates[ SDL_SCANCODE_SPACE ])
                {
                    pigeon->Move(UP, keypress);
                }

                if(currentKeyStates[ SDL_SCANCODE_KP_ENTER ])
                {
                    if(bulletDelay > 50)
                    {
                        //Creates bullet for pigeon
                        p_bullet = new Pigeon_bullet(&gSpriteSheetTexture, pigeon->GetX(), pigeon->GetY(),0);
                        p_bullet->Bullet_Pigeon(pigeon->GetX(), pigeon->GetY());
                        objectList.Enqueue(p_bullet);
                        p_bullet->Move();
                        bulletDelay = 0;
                    }
                }
                objectList.Clean(); //Final cleaning of objects in queues
				SDL_SetRenderDrawColor( gRenderer, 0xFF, 0xFF, 0xFF, 0xFF );    //Clear screen
				SDL_RenderClear( gRenderer );

				scrolling = scrolling - 3; //Background speed
				if (scrolling < -gBackground.GetWidth())
                {
                    scrolling = 0;
                }
                //Render background
                gBackground.Render(scrolling , 0, NULL, 0.0, NULL, SDL_FLIP_NONE, gRenderer);
                gBackground.Render(scrolling + gBackground.GetWidth(), 0, NULL, 0.0, NULL, SDL_FLIP_NONE, gRenderer);
                int i = 0;
                SDL_Rect a2 = {1199, 24, 106, 12};
                SDL_SetRenderDrawColor(gRenderer, 255, 255, 255, 1);
                SDL_RenderDrawRect(gRenderer, &a2);
                while (i < pigeon->GetHealth())
                {
                    healthTexture.Render(1200 + i, 25, NULL, 0.0, NULL, SDL_FLIP_NONE, gRenderer);
                    i++;
                }

                int j = 0;
                SDL_Rect a3 = {1000,24,90,12};
                SDL_SetRenderDrawColor(gRenderer, 255, 255, 255, 1);
                SDL_RenderDrawRect(gRenderer, &a3);
               // cout<<pigeon->GetStealth();
                while(j < pigeon->GetStealth())
                {
                    for(int k = 0; k<30; k++){
                        StealthTexture.Render(1000 + (j*28) +k, 25, NULL, 0.0, NULL, SDL_FLIP_NONE, gRenderer);
                    }
                    j++;
                }





                objectList.Render(frame, gRenderer, true);
                objectList.Move();

                pigeon->Render(frame, gRenderer, true);
                pigeon->Move();
                objectList.P_Detect(pigeon);

                objectList.Clean();
				SDL_RenderPresent( gRenderer );     //Update screen

				pigeon->Move(DOWN, keypress);

				++frame;                            //Go to next frame
				++bulletDelay;

			}
			delete pigeon;
		}
	}

	//Free resources and close SDL
	close();

	return 0;
}

bool init()
{
	//Initialization flag
	bool success = true;

	//Initialize SDL
	if( SDL_Init( SDL_INIT_VIDEO ) < 0 )
	{
		printf( "SDL could not initialize! SDL Error: %s\n", SDL_GetError() );
		success = false;
	}
	else
	{
		//Set texture filtering to linear
		if( !SDL_SetHint( SDL_HINT_RENDER_SCALE_QUALITY, "1" ) )
		{
			printf( "Warning: Linear texture filtering not enabled!" );
		}

		//Create window
		gWindow = SDL_CreateWindow( "SDL Tutorial", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN );
		if( gWindow == NULL )
		{
			printf( "Window could not be created! SDL Error: %s\n", SDL_GetError() );
			success = false;
		}
		else
		{
			//Create renderer for window
			gRenderer = SDL_CreateRenderer( gWindow, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC );
            if( gRenderer == NULL )
            {
                printf( "Renderer could not be created! SDL Error: %s\n", SDL_GetError() );
                success = false;
            }
			else
			{
				//Initialize renderer color
				SDL_SetRenderDrawColor( gRenderer, 0xFF, 0xFF, 0xFF, 0xFF );

				//Initialize PNG loading
				int imgFlags = IMG_INIT_PNG;
				if( !( IMG_Init( imgFlags ) & imgFlags ) )
				{
					printf( "SDL_image could not initialize! SDL_mage Error: %s\n", IMG_GetError() );
					success = false;
				}
			}
		}
	}

	return success;
}

bool loadMedia()
{
	//Loading success flag
	bool success = true;

    if ( !gBackground.LoadFromFile("background.png", gRenderer))
    {
        printf("Failed to load background texture!\n");
        success = false;
    }
	//Load sprite sheet texture
	if( !gSpriteSheetTexture.LoadFromFile( "g.png", gRenderer  ) )
	{
		printf( "Failed to load sprite sheet texture!\n" );
		success = false;
	}
	if (!healthTexture.LoadFromFile("Images/a.png", gRenderer))
    {
        printf( "Failed to load sprite sheet texture!\n" );
		success = false;
    }
    if (!StealthTexture.LoadFromFile("Images/a2.png", gRenderer))
    {
        printf( "Failed to load sprite sheet texture!\n" );
		success = false;
    }

	return success;
}

void close()
{
	//Free loaded images
	gSpriteSheetTexture.Free();
    gBackground.Free();
	//Destroy window
	SDL_DestroyRenderer( gRenderer );
	SDL_DestroyWindow( gWindow );
	gWindow = NULL;
	gRenderer = NULL;
	//Quit SDL subsystems
	IMG_Quit();
	SDL_Quit();
}



