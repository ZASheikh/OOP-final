#pragma once

#include "GameObjects.h"

class Parcel:public GameObjects
{
private:
    static Parcel* instance;
public:
    Parcel(LTexture* image, float x, float y, int type);
    Parcel();
    virtual ~Parcel();
    void Move();
    void Render(long int& frame, SDL_Renderer* gRenderer, bool debug);
    static Parcel* GetInstance(LTexture* image, float x, float y, int type)
    {
        if(instance == NULL)
        {
            instance = new Parcel(image,x,y,type);
        }
        return instance;
    }
};

