#include "GameObjects.h"



GameObjects::GameObjects()
{

}

GameObjects::GameObjects(LTexture* image, float x, float y, int type)
{
    up = false;
    spriteSheetTexture = image;


    //Frame 0
    spriteClips[ 0 ].x = 10;
    spriteClips[ 0 ].y = 450;
    spriteClips[ 0 ].w = 60;
    spriteClips[ 0 ].h = 40;

    //Frame 1
    spriteClips[ 1 ].x = 10;
    spriteClips[ 1 ].y = 490;
    spriteClips[ 1 ].w = 60;
    spriteClips[ 1 ].h = 55;

    //Frame 2
    spriteClips[ 2 ].x = 10;
    spriteClips[ 2 ].y = 550;
    spriteClips[ 2 ].w = 60;
    spriteClips[ 2 ].h = 40;

    //Frame 3
    spriteClips[ 3 ].x = 10;
    spriteClips[ 3 ].y = 590;
    spriteClips[ 3 ].w = 60;
    spriteClips[ 3 ].h = 40;

    this->x = x;
    this->y = y;

    this->width = spriteClips[ 0 ].w;
    this->height = spriteClips[ 0 ].h;

    friction = 0.95f;
    speedx = 0;
    speedy = 0;
    alive  = true;
    animate = false;
    isInteracted = false;
    int frameCount = 0;
    this->type = type;
}


GameObjects::~GameObjects()
{
    spriteSheetTexture = NULL;
}

int GameObjects::GetCount()
{
    return frameCount;
}

void GameObjects::SetCount(int frameCount)
{
    this->frameCount = frameCount;
}

void GameObjects::SetAnimate(bool animate)
{
    this->animate = animate;
}

bool GameObjects::GetAnimate()
{
    return animate;
}

int GameObjects::returnType()
{
    return type;
}

void GameObjects::SetAlive(bool alive)
{
    this->alive = alive;
}

bool GameObjects::GetAlive()
{
    return alive;
}

void GameObjects::Move(int direction, bool keypress)
{

    if(direction==LEFT)
    {
        speedx = -5;
        x+=speedx;
    }

    if(direction==RIGHT)
    {
        speedx = 5;
        x+=speedx;
    }

    if(direction==UP && y>150)
    {
        speedy = -40;
        y+=speedy;

    }

    if(direction==DOWN && y<700)
    {
        speedy = 4;
        y+=speedy;
    }

}

void GameObjects::Move()
{
     speedx = speedx * friction;
     speedy = speedy * friction;

     x = x + speedx;
     y = y + speedy;
}

void GameObjects::Render(long int& frame, SDL_Renderer* gRenderer, bool debug = true)
{
    spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips[ frame % FLYING_FRAMES ], 0.0, NULL, SDL_FLIP_NONE, gRenderer );
    if(debug == true)
    {
        SDL_Rect rect = { x - width/2, y - height/2, width, height };
        SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xFF );
        SDL_RenderDrawRect( gRenderer, &rect );
    }
}

int GameObjects::GetWidth()
{
    return width;
}

void GameObjects::SetIntersect(bool isInteracted)
{
    this->isInteracted = isInteracted;
}

bool GameObjects::GetIntersect()
{
    return isInteracted;
}

int GameObjects::GetHeight()
{
    return height;
}

float GameObjects::GetX()
{
    return x;
}
float GameObjects::GetY()
{
    return y;
}

