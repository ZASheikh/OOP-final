#include "EnemyFactory.h"


EnemyFactory::EnemyFactory()
{
    enemy = NULL;
}

EnemyFactory::~EnemyFactory()
{
    //dtor
}

 Enemy* EnemyFactory:: GetEnemy(LTexture* image, float x, float y, int type)
 {
     if(type == 6)
     {
         enemy = new Infantry(image,x,y,type);
     }
     else if(type == 1)
     {
         enemy = new Plane(image,x,y,type);
     }
     else if(type == 3)
     {
         enemy = new Tank(image,x,y,type);
     }
     return enemy;
 }

