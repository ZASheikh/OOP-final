#ifndef BULLETFACTORY_H
#define BULLETFACTORY_H
#include"Bullet.h"
#include "Infantry_Bullet.h"
#include "Enemy_Bullet.h"
#include "Plane_Bullet.h"

class BulletFactory
{
    public:
        BulletFactory();
        virtual ~BulletFactory();
        Bullet* GetBullet(LTexture* image, float x, float y, int type);

    protected:

    private:
        Bullet* bullet;
};

#endif // BULLETFACTORY_H
