#include "Pigeon_bullet.h"

const int SCREEN_WIDTH = 1350;
const int SCREEN_HEIGHT = 750;


Pigeon_bullet::Pigeon_bullet()
{

}

Pigeon_bullet::~Pigeon_bullet()
{
    cout<<"Bullet Deallocated"<<endl;
}

Pigeon_bullet::Pigeon_bullet(LTexture* image, float x, float y, int type):Bullet(image, x, y, type)
{
    spriteSheetTexture = image;

    //Frame 0
    spriteClips[ 0 ].x = 370;
    spriteClips[ 0 ].y = 120;
    spriteClips[ 0 ].w = 30;
    spriteClips[ 0 ].h = 30;

    /*//Frame 1
    spriteClips[ 1 ].x = 210;
    spriteClips[ 1 ].y = 1055;
    spriteClips[ 1 ].w = 35;
    spriteClips[ 1 ].h = 35;

    //Frame 2
    spriteClips[ 2 ].x = 210;
    spriteClips[ 2 ].y = 1055;
    spriteClips[ 2 ].w = 35;
    spriteClips[ 2 ].h = 35;*/

    this->width = spriteClips[ 0 ].w;
    this->height = spriteClips[ 0 ].h;
}

float Pigeon_bullet::Bullet_Pigeon(float x, float y)
{
    x_coordinate = x;
    y_coordinate = y;
    cout << "A "<<x_coordinate << " " << y_coordinate << endl;
}

void Pigeon_bullet::Move() ///Removed float a and b
{
    x = x - 5*cos(230*PI/180);
    y = y - 5*sin(230*PI/180);
    if (x < -100)
    {
        SetAlive(false);
    }

}


void Pigeon_bullet::Render(long int& frame, SDL_Renderer* gRenderer, bool debug)
{
    spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips[ frame % 1 ], 60.0, NULL, SDL_FLIP_NONE, gRenderer );
    if(debug == true)
    {
        SDL_Rect rect = { x - width/2, y - height/2, width, height };
        SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xFF );
        SDL_RenderDrawRect( gRenderer, &rect );
    }
}
