#ifndef Timer_H
#define Timer_H

#include <SDL.h>
//#include "GameObject.h"
//#include "BonusesPenalties.h"

class Timer
{

    private:
    //The clock Timer when the Timerr started


    //The ticks stored when the Timerr was paused
    int pausedTicks;

    //The Timerr status
    bool paused;
    bool started;

    public:
        int startTicks;
    //Initializes variables
    Timer()
    {
        //Initialize the variables
        startTicks = 0;
        pausedTicks = 0;
        paused = false;
        started = false;
    }

    //The various clock actions
    void start()
    {
        //Start the Timerr
        started = true;

        //Unpause the Timerr
        paused = false;

        //Get the current clock Timer
        startTicks = SDL_GetTicks();
    }

    void stop()
    {
        //Stop the Timerr
        started = false;

        //Unpause the Timerr
        paused = false;
    }

    void pause()
    {
            //If the Timerr is running and isn't already paused
        if( ( started == true ) && ( paused == false ) )
        {
            //Pause the Timerr
            paused = true;

            //Calculate the paused ticks
            pausedTicks = SDL_GetTicks() - startTicks;
        }

    }

    void unpause()
    {
        //If the Timerr is paused
        if( paused == true )
        {
            //Unpause the Timerr
            paused = false;

            //Reset the starting ticks
            startTicks = SDL_GetTicks() - pausedTicks;

            //Reset the paused ticks
            pausedTicks = 0;
        }

    }

    //Gets the Timerr's Timer
    int get_ticks()
    {

            //If the Timerr is running
        if( started == true )
        {
            //If the Timerr is paused
            if( paused == true )
            {
                //Return the number of ticks when the Timerr was paused
                return pausedTicks;
            }
            else
            {
                //Return the current Timer minus the start Timer
                return SDL_GetTicks() - startTicks;
            }

        }

    //If the Timerr isn't running
    return 0;

    }

    //Checks the status of the Timerr
    bool is_started()
    {
        return started;
    }

    bool is_paused()
    {
        return paused;
    }




        void render(SDL_Renderer* renderer, SDL_Rect x , SDL_Rect y)
        {

        }


};


#endif // Timer_H
