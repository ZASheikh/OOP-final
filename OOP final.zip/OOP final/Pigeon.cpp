#include "Pigeon.h"
#include <windows.h>

Pigeon::Pigeon()
{
   // health = 100;
}

Pigeon::~Pigeon()
{

}

Pigeon::Pigeon(LTexture* image, float x, float y,int type):GameObjects(image, x, y, type)
{
    spriteSheetTexture = image;
    health = 100;


//Frame 0
    spriteClips[ 0 ].x = 10;
    spriteClips[ 0 ].y = 320;
    spriteClips[ 0 ].w = 70;
    spriteClips[ 0 ].h = 50;

    //Frame 1
    spriteClips[ 1 ].x = 10;
    spriteClips[ 1 ].y = 370;
    spriteClips[ 1 ].w = 70;
    spriteClips[ 1 ].h = 60;

    //Frame 2
    spriteClips[ 2 ].x = 10;
    spriteClips[ 2 ].y = 430;
    spriteClips[ 2 ].w = 70;
    spriteClips[ 2 ].h = 50;

    //Frame 3
    spriteClips[ 3 ].x = 10;
    spriteClips[ 3 ].y = 480;
    spriteClips[ 3 ].w = 70;
    spriteClips[ 3 ].h = 50;

    this->x = x;
    this->y = y;
    this->width = spriteClips[ 0 ].w;
    this->height = spriteClips[ 0 ].h;

    friction = 0.95f;
    speedx = 0;
    speedy = 0;
    alive  = true;
    animate = false;
    health = 100;
    stealth = 0;
    int frameCount = 0;
    this->type = type;
    s_check = true;
}

int Pigeon::GetHealth()
{
//    cout<<health;
    return health;
}


void Pigeon::SetHealth(int health)
{
    this->health = health;
}

int Pigeon::GetStealth()
{
    return stealth;
}

void Pigeon::Move(int direction, bool keypress)
{


    if(direction==LEFT)
    {
        speedx = -5;
        x+=speedx;
    }

    if(direction==RIGHT)
    {
        speedx = 5;
        x+=speedx;
    }

    if(direction==UP)
    {
        speedy = -10;
        if(y<100){
            speedy = 10;
            if(!s_check && stealth<3){
                stealth++;
               // cout<<stealth<<endl;
            }

            s_check = true;
        }
        y+=speedy;
    }

    if(y>120){
            s_check=false;
    }

    if(direction==DOWN)
    {
        speedy = 4;
        if(y>650){
            speedy = -4;
        }
        y+=speedy;

    }



    if(y==100 && stealth<10)    // To increment stealth
    {

//        s_check = false;
    }

}

void Pigeon::Move()
{
     speedx = speedx * friction;
     speedy = speedy * friction;

     x = x + speedx;
     if ((speedy) < -10)
     {
        s_check = true;
     }
     y = y + speedy;
}


void Pigeon::Render(long int& frame, SDL_Renderer* gRenderer, bool debug)
{
    if (frame % 5 == 0)
        current_frame += 1;
    spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips[ current_frame % FLYING_FRAMES ], 0.0, NULL, SDL_FLIP_NONE, gRenderer );
    if(debug == true)
    {
        SDL_Rect rect = { x - width/2, y - height/2, width, height };
        SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xFF );
        SDL_RenderDrawRect( gRenderer, &rect );
    }
    if (current_frame > 60)
        current_frame = 0 ;
}

