#pragma once

#include "Obstacle.h"

class Eagle:public Obstacle
{
public:
    Eagle(LTexture* image, float x, float y, int type);
    Eagle();
    virtual ~Eagle();
    void Move();
    void Render(long int& frame, SDL_Renderer* gRenderer, bool debug);
protected:
    long int current_frame = 0;
};

