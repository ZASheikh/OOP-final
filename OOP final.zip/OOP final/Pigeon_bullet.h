#pragma once

#include "Bullet.h"

class Pigeon_bullet: public Bullet
{
public:
    Pigeon_bullet(LTexture* image, float x, float y, int type);
    Pigeon_bullet();
    float Bullet_Pigeon(float, float);
    virtual ~Pigeon_bullet();
    void Move();
    void Render(long int& frame, SDL_Renderer* gRenderer, bool debug);

protected:
    double x_coordinate;
    double y_coordinate;
    float angle;
    float gradient;
};


