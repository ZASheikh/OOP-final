#include "Powerup.h"

PowerUp::PowerUp()
{

}

PowerUp::PowerUp(LTexture* image, float x, float y, int type):GameObjects(image, x, y, type)
{
    spriteSheetTexture = image;


    //Frame 0
    spriteClips[ 0 ].x = 240;
    spriteClips[ 0 ].y = 310;
    spriteClips[ 0 ].w = 70;
    spriteClips[ 0 ].h = 70;

    this->width = spriteClips[ 0 ].w;
    this->height = spriteClips[ 0 ].h;
}

PowerUp::~PowerUp()
{
   cout << "Powerup deallocated" << endl;
}

void PowerUp::Move()
{
    x = x - 2;
    if ( x < -100)
    {
        SetAlive(false);
    }
}

void PowerUp::Render(long int& frame, SDL_Renderer* gRenderer, bool debug)
{
    spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips[ frame % 1 ], 0.0, NULL, SDL_FLIP_NONE, gRenderer );
    if(debug == true)
    {
        SDL_Rect rect = { x - width/2, y - height/2, width, height };
        SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xFF );
        SDL_RenderDrawRect( gRenderer, &rect );
    }
}

