#pragma once

#include "GameObjects.h"

class PowerupStealth: public GameObjects
{
public:
    PowerupStealth(LTexture* image, float x, float y, int type);
    PowerupStealth();
    virtual ~PowerupStealth();
    virtual void Move();
    virtual void Render(long int& frame, SDL_Renderer* gRenderer, bool debug);
};



