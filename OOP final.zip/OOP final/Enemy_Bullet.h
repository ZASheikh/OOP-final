#pragma once

#include "Bullet.h"

class Enemy_Bullet: public Bullet
{
public:
    Enemy_Bullet(LTexture* image, float x, float y, int type);
    Enemy_Bullet();
    float Bullet_Pigeon(float, float);
    virtual ~Enemy_Bullet();
    void Move();
    void Render(long int& frame, SDL_Renderer* gRenderer, bool debug);

protected:
    double x_coordinate;
    double y_coordinate;
    float angle;
    float gradient;
};
