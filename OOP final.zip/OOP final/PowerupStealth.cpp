#include "PowerupStealth.h"

PowerupStealth::PowerupStealth()
{

}

PowerupStealth::PowerupStealth(LTexture* image, float x, float y, int type):GameObjects(image, x, y, type)
{
    spriteSheetTexture = image;

    //Frame 0
    spriteClips[ 0 ].x = 370;
    spriteClips[ 0 ].y = 320;
    spriteClips[ 0 ].w = 80;
    spriteClips[ 0 ].h = 70;

    this->width = spriteClips[ 0 ].w;
    this->height = spriteClips[ 0 ].h;
}

PowerupStealth::~PowerupStealth()
{
   cout << "PowerupStealth deallocated" << endl;
}

void PowerupStealth::Move()
{
    x = x - 3;
    if ( x < -100)
    {
        SetAlive(false);
    }
}

void PowerupStealth::Render(long int& frame, SDL_Renderer* gRenderer, bool debug)
{
    spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips[ frame % 1 ], 0.0, NULL, SDL_FLIP_NONE, gRenderer );
    if(debug == true)
    {
        SDL_Rect rect = { x - width/2, y - height/2, width, height };
        SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xFF );
        SDL_RenderDrawRect( gRenderer, &rect );
    }
}


