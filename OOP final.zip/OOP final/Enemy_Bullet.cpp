#include "Enemy_Bullet.h"

const int SCREEN_WIDTH = 1350;
const int SCREEN_HEIGHT = 750;

///
Enemy_Bullet::Enemy_Bullet()
{

}

Enemy_Bullet::~Enemy_Bullet()
{
    cout<<"Enemy_Bullet Deallocated"<<endl;
}

Enemy_Bullet::Enemy_Bullet(LTexture* image, float x, float y, int type):Bullet(image, x, y, type)
{
    spriteSheetTexture = image;

    //Frame 0
    spriteClips[ 0 ].x = 180;
    spriteClips[ 0 ].y = 120;
    spriteClips[ 0 ].w = 30;
    spriteClips[ 0 ].h = 40;

    this->width = spriteClips[ 0 ].w;
    this->height = spriteClips[ 0 ].h;
}

float Enemy_Bullet::Bullet_Pigeon(float x, float y)
{
    x_coordinate = x;
    y_coordinate = y;
    return 0;
    //cout << x_coordinate << " " << y_coordinate << endl;
}

void Enemy_Bullet::Move()
{
    {
        x = x - cos(30*(3.142/180))*7;
        y = y - sin(20*(3.142/180))*7;// - 20;
        if (x < -100)
        {
            SetAlive(false);
        }
    }
}

void Enemy_Bullet::Render(long int& frame, SDL_Renderer* gRenderer, bool debug)
{
    spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips[ frame % 1 ], 120.0, NULL, SDL_FLIP_NONE, gRenderer );
    if(debug == true)
    {
        SDL_Rect rect = { x - width/2, y - height/2, width, height };
        SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xFF );
        SDL_RenderDrawRect( gRenderer, &rect );
    }
}

