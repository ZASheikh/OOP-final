#pragma once
#include"GameObjects.h"

struct Node
{
    GameObjects* unit;
    Node* next;
    Node* prev;

    ~Node()
    {
        delete unit;
    }
};
