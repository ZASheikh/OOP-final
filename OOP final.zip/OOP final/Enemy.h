#pragma once

#include "GameObjects.h"

class Enemy: public GameObjects
{
private:
    SDL_Rect DestroyClips[7];
public:
    Enemy(LTexture* image, float x, float y, int type);
    Enemy();
    virtual ~Enemy();
    virtual void Move();
    virtual void Render(long int& frame, SDL_Renderer* gRenderer, bool debug);
};
