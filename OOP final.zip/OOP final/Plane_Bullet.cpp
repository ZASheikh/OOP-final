#include"Plane_Bullet.h"

const int SCREEN_WIDTH = 1350;
const int SCREEN_HEIGHT = 750;


Plane_Bullet::Plane_Bullet()
{

}

Plane_Bullet::~Plane_Bullet()
{
    cout<<"Bullet Deallocated"<<endl;
}

Plane_Bullet::Plane_Bullet(LTexture* image, float x, float y, int type):Bullet(image, x, y, type)
{
    spriteSheetTexture = image;

    //Frame 0
    spriteClips[ 0 ].x = 150;
    spriteClips[ 0 ].y = 760;
    spriteClips[ 0 ].w = 28;
    spriteClips[ 0 ].h = 28;

    this->width = spriteClips[ 0 ].w;
    this->height = spriteClips[ 0 ].h;
}

float Plane_Bullet::Bullet_Pigeon(float x, float y)
{
    x_coordinate = x;
    y_coordinate = y;
    cout << x_coordinate << " " << y_coordinate << endl;
}

void Plane_Bullet::Move()
{
    //if (y_coordinate > 100)// && y_coordinate < 500)
    {
        x = x - cos(30*(3.142/180))*7;
        y = y + sin(20*(3.142/180))*7;
        if (x < -100 || y > 800)
        {
            SetAlive(false);
        }
    }
}

void Plane_Bullet::Render(long int& frame, SDL_Renderer* gRenderer, bool debug)
{
    spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips[ frame % 1 ], 0.0, NULL, SDL_FLIP_NONE, gRenderer );
    if(debug == true)
    {
        SDL_Rect rect = { x - width/2, y - height/2, width, height };
        SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xFF );
        SDL_RenderDrawRect( gRenderer, &rect );
    }
}

