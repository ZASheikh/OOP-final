#include "Tank.h"

Tank::Tank()
{

}

Tank::~Tank()
{
    cout<<"Tank Deallocated"<<endl;
}

Tank::Tank(LTexture* image, float x, float y, int type):Enemy(image, x, y, type)
{
    spriteSheetTexture = image;


    //Frame 0
    spriteClips[ 0 ].x = 210;
    spriteClips[ 0 ].y = 30;
    spriteClips[ 0 ].w = 70;
    spriteClips[ 0 ].h = 60;

    /*//Frame 1
    spriteClips[ 1 ].x = 150;
    spriteClips[ 1 ].y = 760;
    spriteClips[ 1 ].w = 70;
    spriteClips[ 1 ].h = 60;

    //Frame 2
    spriteClips[ 2 ].x = 150;
    spriteClips[ 2 ].y = 760;
    spriteClips[ 2 ].w = 70;
    spriteClips[ 2 ].h = 60;*/

    DestroyClips[0].x = 3;
    DestroyClips[0].y = 140;
    DestroyClips[0].w = 28;
    DestroyClips[0].h = 25;

    DestroyClips[1].x = 38;
    DestroyClips[1].y = 135;
    DestroyClips[1].w = 32;
    DestroyClips[1].h = 33;

    DestroyClips[2].x = 75;
    DestroyClips[2].y = 130;
    DestroyClips[2].w = 42;
    DestroyClips[2].h = 42;

    DestroyClips[3].x = 115;
    DestroyClips[3].y = 130;
    DestroyClips[3].w = 41;
    DestroyClips[3].h = 40;

    DestroyClips[4].x = 156;
    DestroyClips[4].y = 133;
    DestroyClips[4].w = 37;
    DestroyClips[4].h = 42;

    DestroyClips[5].x = 195;
    DestroyClips[5].y = 132;
    DestroyClips[5].w = 41;
    DestroyClips[5].h = 40;

    DestroyClips[6].x = 235;
    DestroyClips[6].y = 131;
    DestroyClips[6].w = 44;
    DestroyClips[6].h = 38;

    this->width = spriteClips[ 0 ].w;
    this->height = spriteClips[ 0 ].h;
}


void Tank::Move()
{
     x = x - 2;
     if (x < -40)
     {
         SetAlive(false);
     }
}

void Tank::Render(long int& frame, SDL_Renderer* gRenderer, bool debug)
{
    spriteSheetTexture->Render( x- width/2 , y - height/2, &spriteClips[ frame % 1 ], 360.0 , NULL, SDL_FLIP_NONE, gRenderer );
    if(debug == true)
    {
        SDL_Rect rect = { x - width/2, y - height/2, width, height };
        SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xFF );
        SDL_RenderDrawRect( gRenderer, &rect );
    }
}

