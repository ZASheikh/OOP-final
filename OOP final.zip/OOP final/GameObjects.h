#pragma once
#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <iostream>
#include"LTexture.h"

using namespace std;


enum MOTION {RIGHT, LEFT, UP, DOWN};

class GameObjects
{
    protected:
        bool alive;
        float x;
        float y;
        float speedx;
        float speedy;
        int width;
        int height;
        float friction;
        bool up;
        int type;
        bool animate;
        int frameCount;
        bool isInteracted;
        //lower speed means more friction

        enum ANIMATION_FRAMES {FLYING_FRAMES = 4};
        SDL_Rect spriteClips[ FLYING_FRAMES ];
        LTexture* spriteSheetTexture;

    public:
        GameObjects(LTexture* image, float x, float y, int type);
        GameObjects();
        virtual ~GameObjects();
        void SetAlive(bool);
        bool GetAlive();
        int GetWidth();
        int GetHeight();
        float GetX();
        float GetY();
        void SetAnimate(bool);
        bool GetAnimate();
        int GetCount();
        void SetCount(int);
        void SetIntersect(bool);
        bool GetIntersect();
        int returnType();
        virtual void SetHealth(int a){}
        virtual int GetHealth(){return -1;}
        virtual int GetStealth(){return -1;}
        virtual void Move(int direction, bool keypress);
        virtual void Move();
        virtual void Render(long int& frame, SDL_Renderer* gRenderer, bool debug);
};



