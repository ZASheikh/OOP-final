#pragma once
#include "LTexture.h"
#include "GameObjects.h"

class Pigeon: public GameObjects
{
    public:
        Pigeon(LTexture* image, float x, float y,int type);
        Pigeon();
        virtual ~Pigeon();
        int GetHealth();
        int GetStealth();
        void SetHealth(int);
        void Move(int direction, bool keypress);
        void Move();
        void Render(long int& frame, SDL_Renderer* gRenderer, bool debug);
        static Pigeon* GetInstance(LTexture* image, float x, float y,int type)
        {
            if(instance == NULL)
            {
                instance = new Pigeon(image,x,y,type);
            }
            return instance;
        }

    protected:

    private:
        int health;
        int stealth;
        long int current_frame = 0;
        static Pigeon* instance;
        bool s_check=false;
};


