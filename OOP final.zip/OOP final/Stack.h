#pragma once
#include"Node.h"

class Stack
{
private:
    Node* head;
public:
    Stack();
    ~Stack();
    void Push(Unit*);
    int Pop();
    void Show();
    void Render(long int& frame, SDL_Renderer* gRenderer, bool debug);
    void Move();
};
