#pragma once

#include "Enemy.h"

class Tank: public Enemy
{
private:
    SDL_Rect DestroyClips[7];
public:
    Tank(LTexture* image, float x, float y, int type);
    Tank();
    virtual ~Tank();
    void Move();
    void Render(long int& frame, SDL_Renderer* gRenderer, bool debug);
};

