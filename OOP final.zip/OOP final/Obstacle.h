#pragma once

#include "GameObjects.h"

class Obstacle:public GameObjects
{
public:
    Obstacle(LTexture* image, float x, float y, int type);
    Obstacle();
    virtual ~Obstacle();
    virtual void Move();
    virtual void Render(long int& frame, SDL_Renderer* gRenderer, bool debug);
protected:
    long int current_frame = 0;
    int height;
    int width;
};


