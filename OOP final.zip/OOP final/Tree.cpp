#include "Tree.h"
/*#include "LTexture.h"
#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>*/


/*bool Tree::loadMedia()
{
	SDL_Renderer* gRenderer = NULL;

    LTexture gSpriteSheetTexture;
	//Loading success flag
	bool success = true;

	//Load sprite sheet texture
	if( !gSpriteSheetTexture.LoadFromFile( "Tree.png", gRenderer  ) )
	{
		printf( "Failed to load sprite sheet texture!\n" );
		success = false;
	}

	return success;
}*/

Tree::Tree(LTexture* image, float x, float y,int type):Obstacle(image, x, y, type)
{
    spriteSheetTexture = image;


    //Frame 0
    spriteClips[ 0 ].x = 0;
    spriteClips[ 0 ].y = 0;
    spriteClips[ 0 ].w = 70;
    spriteClips[ 0 ].h = 110;

    /*//Frame 1
    spriteClips[ 1 ].x = 0;
    spriteClips[ 1 ].y = 0;
    spriteClips[ 1 ].w = 140;
    spriteClips[ 1 ].h = 210;

    //Frame 2
    spriteClips[ 2 ].x = 0;
    spriteClips[ 2 ].y = 0;
    spriteClips[ 2 ].w = 140;
    spriteClips[ 2 ].h = 210;*/
    this->width = spriteClips[ 0 ].w;
    this->height = spriteClips[ 0 ].h;
}



Tree::~Tree()
{
    cout<<"Tree Deallocated"<<endl;
}

void Tree::Move()
{
     //speedx = speedx * friction;
     //speedy = speedy * friction;

///Interesting idea: we make also make it feel as if the Tree takes of if we use the x wali thing.
         //x = x - speedx;
         //y = y - speedy;
     x = x - 2 ; //speedy;
     if (x < -40)
     {
         SetAlive(false);
     }
}

void Tree::Render(long int& frame, SDL_Renderer* gRenderer, bool debug)
{
    spriteSheetTexture->Render( x - width/2 , y - height/2, &spriteClips[ frame % 1 ], 0.0 , NULL, SDL_FLIP_HORIZONTAL, gRenderer );
    if(debug == true)
    {
        SDL_Rect rect = { x - width/2, y - height/2, width, height };
        SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xFF );
        SDL_RenderDrawRect( gRenderer, &rect );
    }
}

