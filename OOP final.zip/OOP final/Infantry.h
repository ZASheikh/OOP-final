#pragma once

#include "Enemy.h"

class Infantry:public Enemy
{
private:
    SDL_Rect DestroyClips[7];
public:
    Infantry(LTexture* image, float x, float y, int type);
    Infantry();
    virtual ~Infantry();
    void Move();
    void Render(long int& frame, SDL_Renderer* gRenderer, bool debug);
};

