#include "Enemy.h"

Enemy::Enemy()
{

}

Enemy::~Enemy()
{
    cout<<"Enemy Deallocated"<<endl;
}

Enemy::Enemy(LTexture* image, float x, float y, int type):GameObjects(image, x, y, type)
{

}


void Enemy::Move()
{

}

void Enemy::Render(long int& frame, SDL_Renderer* gRenderer, bool debug)
{

}
