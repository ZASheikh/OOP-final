#pragma once

#include "Enemy.h"
#include "Plane.h"
#include "Infantry.h"
#include "Tank.h"

class EnemyFactory
{
    public:
        EnemyFactory();
        virtual ~EnemyFactory();
        Enemy* GetEnemy(LTexture* image, float x, float y, int type);

    protected:

    private:
        Enemy* enemy;
};



