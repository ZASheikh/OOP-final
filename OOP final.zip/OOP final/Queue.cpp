#include"Queue.h"
#include<iostream>

using namespace std;

Queue::Queue()
{
    head = NULL;
    tail = NULL;
}

Queue::~Queue()
{
    while(head != NULL)
    {
        Node* temp = head;
        head = head->next;
        delete temp;
    }
}

void Queue::Enqueue(GameObjects* unit)
{
    if(head == NULL)
    {
        head = new Node;
        head->unit = unit;
        head->next = NULL;
        head->prev = NULL;
        tail = head;
    }
    else
    {
        tail->next = new Node;
        tail->next->unit = unit;
        tail->next->next = NULL;
        tail->next->prev = tail;
        tail = tail->next;
    }
}

void Queue::Clean()
{
    Node* temp = head;
    while(temp!=NULL)
    {
        if(temp->unit->GetAlive() == false || (temp->unit->GetX())<-40)
        {
            if(temp->prev == NULL)
            {
                head=head->next;
                if(head!=NULL)
                {
                    head->prev = NULL;
                }
                delete temp;
                temp = head;
            }
            else if(temp ->next == NULL)
            {
                tail = tail->prev;
                tail->next = NULL;
                delete temp;
                break;
            }
            else
            {
                Node* carry = temp->next;
                temp->prev->next = temp->next;
                temp->next->prev = temp->prev;
                delete temp;
                temp = carry;
            }
        }
        temp = temp->next;
    }
}

SDL_Rect Queue::MakeRect(GameObjects* temp)
{
    SDL_Rect a;
    a.x = (temp->GetX())-(temp->GetWidth()/2);
    a.y = (temp->GetY())-(temp->GetHeight()/2);
    a.h = temp->GetHeight();
    a.w = temp->GetHeight();
    return a;
}

void Queue::C_Detect()
{

    Node* temp = head;
    while(temp!=NULL)
    {
        if(temp->unit->returnType() == 1){
            Node* temp1 = head;
            SDL_Rect a = MakeRect(temp->unit);
            while(temp1!=NULL)
            {
                if(temp1->unit->returnType() == 2)
                {
                    SDL_Rect b = MakeRect(temp1->unit);
                    bool d = SDL_HasIntersection(&a,&b);
                    //cout<<d;
                    if(d)
                    {
                        cout<<"Ho rhi ha bhai"<<endl;
                        temp->unit->SetAnimate(true);
                        if(temp->unit->GetCount()>=6)
                        {
                           cout<<"Fail baba fail"<<endl;
                           temp->unit->SetAlive(false);
                           Clean();
                        }
                    }

                }
                temp1 = temp1->next;
            }
        }
        temp = temp->next;
    }

}

void Queue::P_Detect(GameObjects* pigeon)    // This function checks that if anything is colliding with the pigeon or not.
{

    bool check;
    Node* temp = head;

    while(temp!=NULL)
    {



            SDL_Rect a = MakeRect(pigeon);
            SDL_Rect b = MakeRect(temp->unit);
            check = SDL_HasIntersection(&a,&b);


            if (check && temp->unit->returnType() == 5 && temp->unit->GetIntersect() == false)
            {
                 pigeon->SetHealth(pigeon->GetHealth()- 2);
                 //cout<<pigeon->GetHealth()<<endl;
                 temp->unit->SetIntersect(true);

            }
            else if (check && temp->unit->returnType() == 2 && temp->unit->GetIntersect() == false)
            {
                 pigeon->SetHealth(pigeon->GetHealth()- 4);
                 //cout<<pigeon->GetHealth()<<endl;
                 temp->unit->SetIntersect(true);
            }
            else if (check && temp->unit->returnType() == 7 && temp->unit->GetIntersect() == false)
            {
                 pigeon->SetHealth(pigeon->GetHealth()- 6);
                 //cout<<pigeon->GetHealth()<<endl;
                 temp->unit->SetIntersect(true);
            }
            else if (check && temp->unit->returnType() == 8 && temp->unit->GetIntersect() == false)
            {
                 pigeon->SetHealth(pigeon->GetHealth()- 10);
                 //cout<<pigeon->GetHealth()<<endl;
                 temp->unit->SetIntersect(true);
            }
            else if (check && temp->unit->returnType() == 9)
            {
                 temp->unit->SetAlive(false);
            }
            else if (check && temp->unit->returnType() == 4  && temp->unit->GetIntersect() == false)
            {
                 pigeon->SetHealth(pigeon->GetHealth()- 8);
                 //cout<<pigeon->GetHealth()<<"  hahaja"<<endl;
                 temp->unit->SetIntersect(true);
            }


     temp= temp->next;
    }
}

void Queue::Render(long int& frame, SDL_Renderer* gRenderer, bool debug)
{
    Node* temp = head;
    while(temp!=NULL)
    {
        temp->unit->Render(frame, gRenderer, debug);
        temp->unit->Move();
        temp=temp->next;
    }
}



void Queue::Move()
{
    Node* temp = head;
    while(temp!=NULL)
    {
        temp->unit->Move();
        temp=temp->next;
    }
}
