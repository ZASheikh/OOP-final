#pragma once

#include "Enemy.h"

class Plane: public Enemy
{
public:
    Plane(LTexture* image, float x, float y, int type);
    Plane();
    ~Plane();
    void Move();
    void Render(long int& frame, SDL_Renderer* gRenderer, bool debug);
    bool loadMedia();
};
