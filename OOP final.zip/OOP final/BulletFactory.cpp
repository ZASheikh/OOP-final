#include "BulletFactory.h"


BulletFactory::BulletFactory()
{
    bullet = NULL;
}

BulletFactory::~BulletFactory()
{
    //dtor
}

 Bullet* BulletFactory:: GetBullet(LTexture* image, float x, float y, int type)
 {
     if(type == 7)
     {
         bullet = new Infantry_Bullet(image,x,y,type);
     }
     else if(type == 4)
     {
         bullet = new Enemy_Bullet(image,x,y,type);
     }
     else if(type == 8)
     {
         bullet = new Plane_Bullet(image,x,y,type);
     }
     return bullet;
 }
